AGENT STICKMAN
(First level demo / proof of concept app)

Author: Cyberspider

**Disclaimer: The software is supplied "as is" and all use is at your own risk. The author will not be liable to any personal or property damage caused by the use of this software.**

Warning: Although it may not seem like it, this game is fairly intensive on system requirements due to being built with GameMaker, using large assets and having many enemies on-screen at once. It is recommended to match or exceed the system requirements specified below.
Recommended System Requirements:

Dual Core Processor or better
1 GB RAM or more

Warning: Game may contain bugs or crash at times. Does not save to disk upon closing.

Story So Far...

A dangerous criminal gang called the Bloody Sticks is wreaking havoc downtown. The FBI has summoned you to battle the thugs, eliminate their leader, "The Big Stick" and fetch a critical data disk that might shed light on their motives.

Controls:
A = Move Left
D = Move Right
W = Jump
S = Crouch
Shift (hold) = Run
Left Control (hold) = Drop through platforms
Space = Dodge
Mouse = Aim Crosshair
Left Click = Fire weapon
Right Click = Secondary fire
Middle Mouse = Throw grenade
Middle Mouse (hold) = Aim grenade
1/2/3 = Switch to weapon 1/weapon 2/weapon 3
E = Action button
R = Reload
F = Melee attack
Escape = Menu (shows mission objectives)

To wall-jump: face a wall and jump into it. When you hit the wall, move in the other direction and jump. Quickly turn around when wall-jumping to face the opposite wall and continue wall-jumping.

Gameplay:
-Your goal on each level (this demo only has the first) is to accomplish all of the objectives. To view the current objectives press Escape to go to the menu.
-You start off with 200 health. If it drops to zero you will die and restart at the last checkpoint. Touch checkpoint flags to hit a checkpoint. Collect health packs to replenish health.
-Eliminate enemies in your path. If you fire at an enemy when your crosshair is right on top of them, you will score a direct hit and deal more damage.
-If you press spacebar before a bullet hits you, you can dodge it.
-Headshots with several weapons such as the Pistol, Revolver and Sniper Rifle deal more damage.
-Shooting enemies off screen will result in a 75% miss rate.
-Collect money to purchase upgrades later on in the game. (NOT IMPLEMENTED YET)
-You will earn money upon completing a level. The amount you earn depends on a variety of factors, including # enemies killed, completion time, health left, etc.
-Melee enemies in the head from behind to knock them unconscious for a bit.