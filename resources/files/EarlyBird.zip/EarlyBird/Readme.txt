EARLY BIRD

Version 1.1

Changes from 1.0:
 -Dirt no longer can be tossed off screen (causing crashes on some machines)

**Disclaimer: The software is supplied "as is" and all use is at your own risk. The author will not be liable to any personal or property damage caused by the use of this software.**

Warning: Although it may not seem like it, this game is fairly intensive on system requirements due to the terrain system. It is recommended to match or exceed the system requirements specified below.

Recommended System Requirements:

Dual Core Processor or better
1 GB RAM or more

How To Play

Early Bird is a 2-player, 1-screen game where one player plays as a bird (an American Robin, to be specific) and one player plays as an earthworm. 

To start the game, double-click EarlyBird.exe. The game will open in a window and you will be directed to a menu. Use the arrow keys or W/S to navigate up and down. To select an option, press ENTER.

Select START GAME to start a new game.

The object of the game for the bird is to capture the worm before time runs out. For the worm, it's the opposite: evade the bird until time runs out. The bird can dig holes to try to reach the worm. The worm can dig underground to avoid the bird.

Collect SUN BALLS to decrease the rain percentage. Collect RAIN BALLS to increase the rain percentage. When the rain percentage reaches 100%, it will rain, and the worm will be forced to the surface.

As the bird, press SPACE to peck. If you hit the worm's head or tail, you will enter a tug-of-war sequence. The bird should use WASD to try to pull in the direction perpendicular to the worm's direction. The worm should use the arrow keys to try to pull in the direction opposite that the worm is pulling in. The bird can let go by pressing TILDE.

As the worm, you can hold Right Control to shoot dirt. Every time you hit the bird you get a little time bonus. You can also hold down the DOWN ARROW key to compress yourself, then let go to release, propelling yourself forward. If you go fast enough, you can hit the bird, giving yourself a time boost.

Controls:

Player one (bird) should be on the left side of the keyboard, and should be using WASD. Player two (worm) should be on the right side of the keyboard and should be using the arrow keys.

Bird:
W: Jump (hold to fly)
S: Dig
A: Move left
D: Move right
Space: Peck
Tilde: Let go of worm (when tugging)

Worm:
Up arrow: move forward
Left arrow: Turn left
Right arrow: Turn right
Down arrow: Compress (release to launch)
Left Ctrl: Shoot dirt